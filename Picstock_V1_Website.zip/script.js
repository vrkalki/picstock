const items=[
 {title:"Divine Diya",cat:"devotional",icon:"🪔"},
 {title:"Temple Bell",cat:"devotional",icon:"🔔"},
 {title:"Lotus Flower",cat:"flowers",icon:"🌸"},
 {title:"Decorative Floral",cat:"flowers",icon:"🌺"},
 {title:"Golden Round Frame",cat:"frames",icon:"⭕"},
 {title:"Elegant Text Frame",cat:"frames",icon:"✦"},
 {title:"Wedding Rings",cat:"wedding",icon:"💍"},
 {title:"Wedding Decoration",cat:"wedding",icon:"💐"},
 {title:"Golden Ornament",cat:"decorations",icon:"✨"},
 {title:"Traditional Decor",cat:"decorations",icon:"🪷"},
 {title:"Indian Character",cat:"people",icon:"🧑"},
 {title:"Elephant Element",cat:"animals",icon:"🐘"}
];
const gallery=document.getElementById("gallery"), input=document.getElementById("searchInput"), count=document.getElementById("resultCount"), empty=document.getElementById("empty");
function render(list){
 gallery.innerHTML="";
 list.forEach((x,i)=>{
   const card=document.createElement("article"); card.className="card";
   card.innerHTML=`<div class="preview"><div class="fake-art">${x.icon}</div></div>
   <div class="info"><h3>${x.title}</h3><p>Transparent PNG • ${x.cat}</p><a class="download" href="#" download="picstock-${x.title.toLowerCase().replaceAll(" ","-")}.png" onclick="demoDownload(event)">Download PNG</a></div>`;
   gallery.appendChild(card);
 });
 count.textContent=list.length+" resources";
 empty.hidden=list.length>0;
}
function search(q){q=q.trim().toLowerCase();render(items.filter(x=>!q||x.title.toLowerCase().includes(q)||x.cat.includes(q)))}
function demoDownload(e){e.preventDefault();alert("Demo button: replace this sample artwork with your real PNG file in the /png folder.");}
document.getElementById("searchBtn").onclick=()=>search(input.value);
input.addEventListener("keydown",e=>{if(e.key==="Enter")search(input.value)});
document.querySelectorAll("[data-search]").forEach(b=>b.onclick=()=>{input.value=b.dataset.search;search(b.dataset.search)});
document.querySelectorAll("[data-cat]").forEach(b=>b.onclick=()=>{input.value=b.dataset.cat;search(b.dataset.cat);document.getElementById("latest").scrollIntoView({behavior:"smooth"})});
render(items);
